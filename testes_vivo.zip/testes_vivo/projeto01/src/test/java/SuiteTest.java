import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SuiteTest {

    @DisplayName("Recargas realizadas | valida conta -> saldo | Sucesso")
    @Tag("recargas_valida_conta_saldo")
    @ParameterizedTest
    @MethodSource("recargasCasesContaSaldo")
    public void recargasValidaContaSaldoTest(Cliente cliente, int result) {
        assertEquals(result, cliente.getConta().getSaldo());

    }

    public static Stream<Arguments> recargasCasesContaSaldo() {
        return Stream.of(
                Arguments.of(new Cliente("joão",new Telefone("489999",0),new Conta(10)).realizarRecarga(10),0),
                Arguments.of(new Cliente("joão",new Telefone("489999",0),new Conta(11)).realizarRecarga(10),1)
        );
    }

    @DisplayName("Recargas realizadas | valida conta -> saldo | Exception")
    @Tag("recargas_valida_conta_saldo_exception")
    @ParameterizedTest
    @MethodSource("recargasCasesContaSaldoException")
    public void recargasValidaContaSaldoExceptionTest(Cliente cliente, int result) {
        assertThrows(NullPointerException.class,()->{cliente.getConta().getSaldo();});
    }

    public static Stream<Arguments> recargasCasesContaSaldoException() {
        return Stream.of(
                Arguments.of(new Cliente("joão",new Telefone("489999",10),new Conta(9)).realizarRecarga(10),0),
                Arguments.of(new Cliente("joão",new Telefone("489999",10),new Conta(10)).realizarRecarga(-1),10),
                Arguments.of(new Cliente("joão",new Telefone("489999",10),new Conta(-1)).realizarRecarga(10),9)
        );
    }

    @DisplayName("Recargas realizadas | valida telefone -> saldo | Sucesso")
    @Tag("recargas_valida_telefone_saldo")
    @ParameterizedTest
    @MethodSource("recargasCasesTelefoneSaldo")
    public void recargasValidaSaldosSucessoTest(Cliente cliente, int result) {
        assertEquals(result,cliente.getTelefone().getSaldo());
    }

    public static Stream<Arguments> recargasCasesTelefoneSaldo() {
        return Stream.of(
                Arguments.of(new Cliente("joão",new Telefone("489999",0),new Conta(10)).realizarRecarga(10),10),
                Arguments.of(new Cliente("joão",new Telefone("489999",1),new Conta(10)).realizarRecarga(10),11),
                Arguments.of(new Cliente("joão",new Telefone("489999",-1),new Conta(10)).realizarRecarga(10),9)

        );
    }

    @DisplayName("Recargas realizadas | valida telefone -> saldo | Exception")
    @Tag("recargas_valida_telefone_saldo_exception")
    @ParameterizedTest
    @MethodSource("recargasCasesTelefoneSaldoException")
    public void recargasValidaSaldosExceptionTest(Cliente cliente, int result) {
        assertThrows(NullPointerException.class,()->{cliente.getTelefone().getSaldo();});
    }

    public static Stream<Arguments> recargasCasesTelefoneSaldoException() {
        return Stream.of(
                Arguments.of(new Cliente("joão",new Telefone("489999",0),new Conta(9)).realizarRecarga(10),10),
                Arguments.of(new Cliente("joão",new Telefone("489999",1),new Conta(8)).realizarRecarga(10),10),
                Arguments.of(new Cliente("joão",new Telefone("489999",9),new Conta(-1)).realizarRecarga(10),9),
                Arguments.of(new Cliente("joão",new Telefone("489999",0),new Conta(0)).realizarRecarga(0),0),
                Arguments.of(new Cliente("joão",new Telefone("489999",10),new Conta(0)).realizarRecarga(10),10)
        );
    }

}
