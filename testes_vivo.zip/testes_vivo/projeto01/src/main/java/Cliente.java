public class Cliente {

    private String nome_cliente;
    private Telefone telefone;
    private Conta conta;

    public Cliente(String nome_cliente, Telefone telefone, Conta conta){
        this.nome_cliente=nome_cliente;
        this.telefone=telefone;
        this.conta=conta;
    }

    public void setNome(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    public String getNome() {
        return this.nome_cliente;
    }

    public void setLinha(Telefone telefone) {
        this.telefone = telefone;
    }

    public Telefone getTelefone() {
        return this.telefone;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }

    public Conta getConta() {
        return this.conta;
    }

    public Cliente realizarRecarga(int valor_recarga){
        try{
            if( valor_recarga > 0){
                if(getConta().getSaldo() >= valor_recarga){
                    getConta().setRecarga(valor_recarga);
                    getConta().setSaldo(this.getConta().getSaldo() - valor_recarga);
                    getTelefone().setSaldo(this.getTelefone().getSaldo() + valor_recarga);
                    return this;
                }else{
                    return null;
                }
            }else{
                return null;
            }
        }catch (NullPointerException ex){
            return null;
        }catch (Exception e){
            return null;
        }
    }

}
