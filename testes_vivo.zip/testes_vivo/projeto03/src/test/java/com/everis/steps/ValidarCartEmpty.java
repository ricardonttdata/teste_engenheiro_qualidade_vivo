package com.everis.steps;

import com.everis.pages.CartEmptyPage;
import com.everis.pages.CheckoutPage;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;

public class ValidarCartEmpty {

    @Quando("removo o produdo do carrinho")
    public void removoOProdudoDoCarrinho() {
        new CheckoutPage().clickRemoveProductCart();
    }

    @Entao("valido se o carrinho de compras esta vazio")
    public void validoSeOCarrinhoDeComprasEstaVazio() {
        Assert.assertEquals(new CartEmptyPage().getTextEmptyCart(),"Your shopping cart is empty");
    }
}
