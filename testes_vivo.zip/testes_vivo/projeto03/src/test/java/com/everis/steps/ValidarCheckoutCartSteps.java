package com.everis.steps;

import com.everis.pages.*;
import com.everis.repository.MassaDadosRepository;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;

import java.util.Map;

public class ValidarCheckoutCartSteps {

    private MassaDadosRepository massaDadosRepository;
    private Map<String, String> resultMap;

    public ValidarCheckoutCartSteps(){
        massaDadosRepository = new MassaDadosRepository();
        resultMap = massaDadosRepository.getMassa();
    }

    @Quando("acesso a opcao de busca por produto")
    public void acessoAOpcaoDeBuscaPorProduto() {
        new HomePage().clickLinkSearch();
        new HomePage().writeProductSearch(resultMap.get("NAME_PRODUCT"));
    }

    @Quando("seleciono o produto")
    public void selecionoOProduto() {
        new SearchPage().clickSearchProductResult();
    }

    @Quando("altero a cor do produto para uma diferente")
    public void alteroACorDoProdutoParaUmaDiferente() {
        new ProductDetailsPage().selectColorProduct("RED");
    }

    @Quando("altero a quantidade de produtos")
    public void alteroAQuantidadeDeProdutos() {
        new ProductDetailsPage().clickSum(2);
    }

    @Entao("valido a soma dos precos no carrinho")
    public void validoASomaDosPrecosNoCarrinho() {
        Assert.assertEquals(new CheckoutPage().getValueTotalCheckout(),"$1,349.97");
    }

    @Entao("atualizo a massa de dados com a nova cor do produto")
    public void atualizoAMassaDeDadosComANovaCorDoProduto() {
        Assert.assertEquals(massaDadosRepository.updateColorMassa("RED"),true);
    }
}
