package com.everis.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.Collator;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.hotkey.Keys;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Finder;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Key;
import org.sikuli.script.Location;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Region;
import org.sikuli.script.Screen;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;

import io.github.marcoslimaqa.sikulifactory.SikuliElement;

public class BasePage {

    protected WebDriver driver = TestRule.getDriver();
    protected ExtentTest extentTest = TestRule.getExtentTest();
    protected ExtentReports extentReport = TestRule.getExtentReports();
    protected Screen sikuli = TestRule.getSikuli();
    protected App sikuliApp = TestRule.getSikuliApp();
    protected boolean isSikuliAutomation = "sikuli".equals(TestRule.getActiveAutomation());
    public final Logger logger = Logger.getLogger(BasePage.class);

    public BasePage() {}

    protected void wait_(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
            logger.error("Erro ao executar wait(int seconds)", e);
        }
    }


    private String saveScreenshotInRelatoriosPath() {
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1;
        int year = calendar.get(Calendar.YEAR);
        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minutes = calendar.get(Calendar.MINUTE);
        int seconds = calendar.get(Calendar.SECOND);
        int milliseconds = calendar.get(Calendar.MILLISECOND);
        String datahora = "" + day + month + year + "_" + hours + minutes + seconds + milliseconds;
        String screenShotName = datahora + ".png";
        File scrFile = null;
        try {
            if (isSikuliAutomation) {
                scrFile = new File("target/report/html/img/" + screenShotName);
                try {
                    ImageIO.write(sikuli.capture(App.focusedWindow()).getImage(), "png", scrFile);
                } catch (Exception e) {
                    ImageIO.write(sikuli.capture().getImage(), "png", scrFile);
                    logger.debug("Erro ao obter screenshot do app, possivelmente o app '" + sikuliApp.getName()
                            + "' nao esta em execucao." + "Obtido screenshot da tela inteira.");
                }
            } else {
                scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(scrFile, new File("target/report/html/img/" + screenShotName));
            }
        } catch (IOException e) {
            logger.error("Erro ao salvar screenshot.", e);
        }
        return screenShotName;
    }

    public void logPrintFail(String log) {
        String screenShotName = saveScreenshotInRelatoriosPath();
        try {
            extentTest.fail(log, MediaEntityBuilder.createScreenCaptureFromPath("img/" + screenShotName).build());
        } catch (IOException e) {
            logger.error("Erro ao executar logPrintFail()", e);
        }
    }

    protected boolean waitForElementToBeClickable(WebElement element, int timeOutInSeconds) {
        WebElement webElement = null;
        try {
            @SuppressWarnings("deprecation")
            Wait<WebDriver> wait = new FluentWait<WebDriver>(TestRule.getDriver()).withTimeout(timeOutInSeconds, TimeUnit.SECONDS)
                    .pollingEvery(200, TimeUnit.MILLISECONDS).ignoring(NoSuchElementException.class)
                    .ignoring(StaleElementReferenceException.class).ignoring(TimeoutException.class);
            webElement = wait.until(ExpectedConditions.elementToBeClickable(element));
        } catch (NoSuchElementException e) {
            return false;
        } catch (StaleElementReferenceException e) {
            return false;
        } catch (TimeoutException e) {
            return false;
        }
        return webElement != null;
    }

    public void waitForElementToBeClickableWhile(WebElement element, int timeOutInSeconds){
        boolean flag=false;
        while(!flag){
            flag =  waitForElementToBeClickable(element,timeOutInSeconds);
        }

    }

    public static Boolean existe(By by, int timeout) {
        if(TestRule.getDriver().findElements(by).size() > 0) {
            return true;
        } else {
            return false;
        }
    }

}
