package com.everis.repository;

import com.everis.utils.Utils;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MassaDadosRepository extends  ConnectionFactory{

    private static Connection connect;
    private static Statement statement;
    private static ResultSet results;

    private static Map<String, String> resultMap;
    private static String[] collunmsDB = {"NAME_PRODUCT", "CUSTOMIZATION","DISPLAY","DISPLAY_RESOLUTION","DISPLAY_SIZE","MEMORY","OPERATING_SYSTEM","PROCESSOR","TOUCHSCREEN","WEIGHT","COLOR"};

    public MassaDadosRepository(){
        connect = getConnection();
    }

    public Map<String, String> getMassa()  {
        String sql = "SELECT * FROM massas";
        try {
            statement = connect.createStatement();
            results = statement.executeQuery(sql);
            resultMap = new HashMap<>();
            resultMap = Utils.mapResultDBGenerator(results, collunmsDB);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resultMap;
    }

    public boolean updateColorMassa(String newColor)  {
        String sql = "UPDATE massas SET COLOR = '"+newColor+"' " +
                " WHERE NAME_PRODUCT = 'HP PAVILION 15Z TOUCH LAPTOP' ";
        try {
            statement = connect.createStatement();
            int retorno = statement.executeUpdate(sql);
            if(retorno > 0)
                return true;
            else
                return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean restoreColorMassa()  {
        String sql = "UPDATE massas SET " +
                "COLOR = 'GRAY'" +
                " WHERE NAME_PRODUCT = 'HP PAVILION 15Z TOUCH LAPTOP' ";
        try {
            statement = connect.createStatement();
            int retorno = statement.executeUpdate(sql);
            if(retorno > 0)
                return true;
            else
                return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
