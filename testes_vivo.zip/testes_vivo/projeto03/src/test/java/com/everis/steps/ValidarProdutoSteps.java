package com.everis.steps;

import com.everis.pages.InitialPage;
import com.everis.pages.ProductDetailsPage;
import com.everis.pages.HomePage;
import com.everis.repository.MassaDadosRepository;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;

import java.util.Map;

public class ValidarProdutoSteps {

    private MassaDadosRepository massaDadosRepository;
    private Map<String, String> resultMap;

    public ValidarProdutoSteps(){
        massaDadosRepository = new MassaDadosRepository();
        resultMap = massaDadosRepository.getMassa();
    }

    @Dado("que acesso o site")
    public void queAcessoOSite() {
        new InitialPage().acessarSistema();
    }

    @Quando("acesso a opcao Special Offer")
    public void acessoAOpcaoSpecialOffer()  {
        new HomePage().clickLinkOfferSpecial();
    }

    @Quando("clico no botao See offer")
    public void clicoNoBotaoSeeOffer() {
        new HomePage().clickButtonSeeOffer();
    }
    @Entao("valido as especificacoes do produto")
    public void validoAsEspecificacoesDoProduto() {
        Assert.assertEquals(new ProductDetailsPage().getNameProduct(),resultMap.get("NAME_PRODUCT"));
        Assert.assertEquals(new ProductDetailsPage().getCustomizationProduct(),resultMap.get("CUSTOMIZATION"));
        Assert.assertEquals(new ProductDetailsPage().getDisplayProduct(),resultMap.get("DISPLAY"));
        Assert.assertEquals(new ProductDetailsPage().getDisplayResolutionProduct(),resultMap.get("DISPLAY_RESOLUTION"));
        Assert.assertEquals(new ProductDetailsPage().getDisplaySizeProduct(),resultMap.get("DISPLAY_SIZE"));
        Assert.assertEquals(new ProductDetailsPage().getMemoryProduct(),resultMap.get("MEMORY"));
        Assert.assertEquals(new ProductDetailsPage().getOperatingSystemProduct(),resultMap.get("OPERATING_SYSTEM"));
        Assert.assertEquals(new ProductDetailsPage().getProcessorProduct(),resultMap.get("PROCESSOR"));
        Assert.assertEquals(new ProductDetailsPage().getTouchscreenProduct(),resultMap.get("TOUCHSCREEN"));
        Assert.assertEquals(new ProductDetailsPage().getWeightProduct(),resultMap.get("WEIGHT"));
    }
}
