package com.everis.pages;

import com.everis.attributes.HomeAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.support.PageFactory;

public class HomePage extends HomeAttributes {

    public HomePage(){
        wait_(2);
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public void clickLinkOfferSpecial() {
        waitForElementToBeClickableWhile(linkSpecialOffer,1);
        linkSpecialOffer.click();
    }

    public void clickButtonSeeOffer(){
        waitForElementToBeClickableWhile(buttonSeeOffer,1);
        buttonSeeOffer.click();
    }

    public void clickLinkSearch(){
        waitForElementToBeClickableWhile(linkSearch,1);
        linkSearch.click();
    }

    public void writeProductSearch(String nameProduct){
        wait_(3);
        inputTextSearch.sendKeys(nameProduct);
    }

}
