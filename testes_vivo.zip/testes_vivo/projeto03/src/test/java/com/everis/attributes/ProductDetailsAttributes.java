package com.everis.attributes;

import com.everis.pages.ProductDetailsPage;
import com.everis.utils.BasePage;
import com.everis.utils.TestRule;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductDetailsAttributes extends BasePage {

    @FindBy(xpath = "//div[@id='Description']/h1")
    protected WebElement nameProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[1]/label[2]")
    protected WebElement customizationProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[2]/label[2]")
    protected WebElement displayProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[3]/label[2]")
    protected WebElement displayResolutionProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[4]/label[2]")
    protected WebElement displaySizeProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[5]/label[2]")
    protected WebElement memoryProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[6]/label[2]")
    protected WebElement operatingSystemProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[7]/label[2]")
    protected WebElement processorProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[8]/label[2]")
    protected WebElement touchscreenProduct;

    @FindBy(xpath = "//body/div[3]/section[1]/article[2]/div[9]/label[2]")
    protected WebElement weightProduct;

    @FindBy(xpath = "//span[contains(@class,'bunny productColor ng-scope GRAY')]")
    protected WebElement colorGrayProduct;

    @FindBy(xpath = "//button[@name='save_to_cart'][contains(.,'ADD TO CART')]")
    protected WebElement buttonAddToCart;

    @FindBy(xpath = "//*[@id='menuCart']")
    protected WebElement buttonMenuCart;

    @FindBy(xpath = "//span[contains(@class,'bunny productColor ng-scope BLUE')]")
    protected WebElement colorBlueProductCart;

    @FindBy(xpath = "//span[contains(@class,'bunny productColor ng-scope GRAY')]")
    protected WebElement colorGrayProductCart;

    @FindBy(xpath = "//span[contains(@class,'bunny productColor ng-scope YELLOW')]")
    protected WebElement colorYellowProductCart;

    @FindBy(xpath = "//span[contains(@class,'bunny productColor ng-scope RED')]")
    protected WebElement colorRedProductCart;

    @FindBy(xpath = "//div[@class='plus']")
    protected WebElement buttonSum;
}
