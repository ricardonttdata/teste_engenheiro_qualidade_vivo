package com.everis.pages;

import com.everis.attributes.ProductDetailsAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProductDetailsPage extends ProductDetailsAttributes {


    public ProductDetailsPage(){
        wait_(3);
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public String getNameProduct(){
        wait_(2);
        return nameProduct.getText();
    }

    public String getCustomizationProduct(){
        return customizationProduct.getText();
    }

    public String getDisplayProduct(){
        return displayProduct.getText();
    }

    public String getDisplayResolutionProduct(){
        return displayResolutionProduct.getText();
    }

    public String getDisplaySizeProduct(){
        return displaySizeProduct.getText();
    }

    public String getMemoryProduct(){
        return memoryProduct.getText();
    }

    public String getOperatingSystemProduct(){
        return operatingSystemProduct.getText();
    }

    public String getProcessorProduct(){
        return processorProduct.getText();
    }

    public String getTouchscreenProduct(){
        return touchscreenProduct.getText();
    }

    public String getWeightProduct(){
        return weightProduct.getText();
    }

    public void clickOptionColorGrayProduct(){
        colorGrayProduct.click();
    }

    public void clickAddToCart(){
        buttonAddToCart.click();
    }

    public void clickMenuToCart(){
        buttonMenuCart.click();
    }

    public void selectColorProduct(String color){
        switch (color.toUpperCase()){
            case"GRAY":
                waitForElementToBeClickableWhile(colorGrayProductCart,1);
                colorGrayProductCart.click();
                break;
            case"RED":
                waitForElementToBeClickableWhile(colorRedProductCart,1);
                colorRedProductCart.click();
                break;
            case"YELLOW":
                waitForElementToBeClickableWhile(colorYellowProductCart,1);
                colorYellowProductCart.click();
                break;
            case"BLUE":
                waitForElementToBeClickableWhile(colorBlueProductCart,1);
                colorBlueProductCart.click();
                break;
            default:
                break;
        }
    }

    public void clickSum(int qtdSum){
        while (qtdSum > 0){
            waitForElementToBeClickableWhile(buttonSum,1);
            buttonSum.click();
            qtdSum--;
        }
    }
}
