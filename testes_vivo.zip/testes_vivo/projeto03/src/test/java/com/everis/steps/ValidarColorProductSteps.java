package com.everis.steps;

import com.everis.pages.CheckoutPage;
import com.everis.pages.ProductCartPage;
import com.everis.pages.ProductDetailsPage;
import com.everis.repository.MassaDadosRepository;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;
import org.junit.Assert;

import java.util.Map;

public class ValidarColorProductSteps {

    private MassaDadosRepository massaDadosRepository;
    private Map<String, String> resultMap;

    public ValidarColorProductSteps(){
        massaDadosRepository = new MassaDadosRepository();
        resultMap = massaDadosRepository.getMassa();
    }

    @Quando("altero a cor do produto")
    public void alteroACorDoProduto() {
        new ProductDetailsPage().clickOptionColorGrayProduct();
    }

    @Quando("adiciono o produto no carrinho")
    public void adicionoOProdutoNoCarrinho() {
        new ProductDetailsPage().clickAddToCart();
    }

    @Entao("valido que o produto foi adicionado no carrinho")
    public void validoQueOProdutoFoiAdicionadoNoCarrinho() {
        Assert.assertEquals(new ProductCartPage().getNameProductCart(),resultMap.get("NAME_PRODUCT"));
    }

    @Entao("valido a cor do produto")
    public void validoACorDoProduto() {
        new ProductDetailsPage().clickMenuToCart();
        Assert.assertEquals(new ProductCartPage().getColorProductCart("GRAY"),resultMap.get("COLOR"));
    }

    @Quando("acesso a pagina de checkout")
    public void acessoAPaginaDeCheckout() {
        new CheckoutPage().clickButtonCkeckout();
    }

    @Quando("acesso o carrinho de compras")
    public void acessoOCarrinhoDeCompras() {
        new ProductDetailsPage().clickMenuToCart();
    }

}
