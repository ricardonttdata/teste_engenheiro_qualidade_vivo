package com.everis.attributes;

import com.everis.utils.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CheckoutAttributes extends BasePage {

    @FindBy(xpath = "//span[@class='roboto-medium totalValue ng-binding']")
    protected WebElement textTotalValueCheckout;

    @FindBy(id = "checkOutButton")
    protected WebElement buttonCheckout;

    @FindBy(xpath = "//a[@class='remove red ng-scope'][contains(.,'REMOVE')]")
    protected WebElement linkRemoverProductCart;

}
