package com.everis.attributes;

import com.everis.utils.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CartEmptyAttributes extends BasePage {

    @FindBy(xpath = "//label[@class='roboto-bold ng-scope']")
    protected WebElement textEmptyCart;

}
