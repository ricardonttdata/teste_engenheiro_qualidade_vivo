package com.everis.attributes;

import com.everis.utils.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomeAttributes extends BasePage {

    @FindBy(xpath = "//a[contains(@translate,'SPACIAL_OFFER')]")
    public WebElement linkSpecialOffer;

    @FindBy(xpath = "//button[contains(@translate,'SEE_OFFER')]")
    protected WebElement buttonSeeOffer;

    @FindBy(xpath = "//a[@title='SEARCH']//*[@id='menuSearch']")
    protected WebElement linkSearch;

    @FindBy(xpath = "//input[@placeholder='Search AdvantageOnlineShopping.com']")
    protected WebElement inputTextSearch;

}
