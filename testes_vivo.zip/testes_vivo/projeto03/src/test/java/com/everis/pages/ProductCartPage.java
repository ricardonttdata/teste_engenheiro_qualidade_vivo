package com.everis.pages;

import com.everis.attributes.ProductCartAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.support.PageFactory;

public class ProductCartPage extends ProductCartAttributes {

    public ProductCartPage(){
        wait_(2);
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public String getNameProductCart(){
        return nameProductCart.getText();
    }

    public String getColorProductCart(String color){
        wait_(2);
        switch (color.toUpperCase()){
            case"GRAY":
                return colorGrayProductCart.getText();
            case"RED":
                return colorRedProductCart.getText();
            case"YELLOW":
                return colorYellowProductCart.getText();
            case"BLUE":
                return colorBlueProductCart.getText();
            default:
                return "";
        }
    }






}
