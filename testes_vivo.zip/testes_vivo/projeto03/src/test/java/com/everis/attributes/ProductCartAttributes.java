package com.everis.attributes;

import com.everis.utils.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductCartAttributes extends BasePage {

    @FindBy(xpath = "//span[@class='ng-binding'][contains(.,'GRAY')]")
    protected WebElement colorGrayProductCart;

    @FindBy(xpath = "//span[@class='ng-binding'][contains(.,'YELLOW')]")
    protected WebElement colorYellowProductCart;

    @FindBy(xpath = "//span[@class='ng-binding'][contains(.,'RED')]")
    protected WebElement colorRedProductCart;

    @FindBy(xpath = "//span[@class='ng-binding'][contains(.,'BLUE')]")
    protected WebElement colorBlueProductCart;

    @FindBy(xpath = "//label[contains(.,'HP PAVILION 15Z TOUCH LAPTOP')]")
    protected WebElement nameProductCart;


}
