package com.everis.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    private static Connection conn;
    private static String host = "localhost";
    private static String dataBase = "banco_teste_automacao";
    private static String user = "root";
    private static String senha = "root";

    public static Connection getConnection() {
        if(conn == null) {
            try {
                conn = DriverManager.getConnection(
                        "jdbc:mysql://" + host + "/" + dataBase+"?user="+user+"&password="+senha );
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return conn;
    }

    public static void closeConnection() throws SQLException {
        if(conn != null) {
            conn.close();
        }
        conn = null;
    }

}
