package com.everis.attributes;

import com.everis.utils.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SearchAttributes extends BasePage {

    @FindBy(xpath = "//p[@class='roboto-regular ng-binding'][contains(.,'HP PAVILION 15Z TOUCH LAPTOP')]")
    protected WebElement linkProductResult;
}
