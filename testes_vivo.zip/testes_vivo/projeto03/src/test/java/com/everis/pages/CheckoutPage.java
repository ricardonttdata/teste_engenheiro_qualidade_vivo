package com.everis.pages;

import com.everis.attributes.CheckoutAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.support.PageFactory;

public class CheckoutPage extends CheckoutAttributes {

    public CheckoutPage(){
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public String getValueTotalCheckout(){
        wait_(3);
        return textTotalValueCheckout.getText();
    }

    public void clickButtonCkeckout(){
        waitForElementToBeClickableWhile(buttonCheckout,1);
        buttonCheckout.click();
    }

    public void clickRemoveProductCart(){
        waitForElementToBeClickableWhile(linkRemoverProductCart,1);
        linkRemoverProductCart.click();
    }

}
