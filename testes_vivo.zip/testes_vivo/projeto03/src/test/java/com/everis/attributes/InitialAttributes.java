package com.everis.attributes;

import com.everis.utils.BasePage;

public class InitialAttributes extends BasePage {


}
