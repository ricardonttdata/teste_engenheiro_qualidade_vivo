package com.everis.pages;

import com.everis.attributes.SearchAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.support.PageFactory;

public class SearchPage extends SearchAttributes {

    public SearchPage(){
        wait_(1);
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public void clickSearchProductResult(){
        waitForElementToBeClickableWhile(linkProductResult,1);
        linkProductResult.click();
    }
}
