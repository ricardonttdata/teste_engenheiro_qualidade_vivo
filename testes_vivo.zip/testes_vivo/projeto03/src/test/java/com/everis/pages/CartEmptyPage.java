package com.everis.pages;

import com.everis.attributes.CartEmptyAttributes;
import com.everis.utils.TestRule;
import org.openqa.selenium.support.PageFactory;

public class CartEmptyPage extends CartEmptyAttributes {

    public CartEmptyPage(){
        PageFactory.initElements(TestRule.getDriver(), this);
    }

    public String getTextEmptyCart(){
        wait_(2);
        return textEmptyCart.getText();
    }
}
