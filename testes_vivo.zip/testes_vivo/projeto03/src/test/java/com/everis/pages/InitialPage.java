package com.everis.pages;

import com.everis.attributes.InitialAttributes;
import com.everis.utils.TestRule;

public class InitialPage extends InitialAttributes {

    public void acessarSistema(){
        TestRule.openApplication("chrome","https://advantageonlineshopping.com" );
        waitForElementToBeClickableWhile(new HomePage().linkSpecialOffer,1);
    }
}
