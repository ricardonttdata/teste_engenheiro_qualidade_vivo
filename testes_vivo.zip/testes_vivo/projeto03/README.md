# Gerador de Massas - Siebel


### Atualização

* Sprint 1 - Fluxo de criação de Cliente e adicionar o endereço, Fluxo de Perfil de Cobrança


O projeto de massas Siebel contém processos de criação e ajustes de massa. 

         
### Ferramentas e linguagens utilizadas
 - [ ] LeanFT
 - [X] Selenium
 - [x] Java
 - [x] Maven

### Pacotes utilizados para automação :
- [X] Web
- [ ] Windows
- [ ] Insight Object
- [x] Java 
- [ ] SSH
- [x] API
- [ ] Mobile
- [ ] SAP
- [X] Banco de dados


### Pacotes existentes para Manipulação de Massa de Teste :
- [ ] Planilha
        

### Projetos Importados:

  - [x] massas-vivo
                                

## Configuração


## Features
##### Criacao Cliente Siebel

  - [x] Login Siebel 
  - [ ] Criar Cliente
  - [ ] Checar disponibilidade de CEP
  - [ ] Criar perfil cobrança
  - [ ] Vendar de produtos

  
##### Settings

  - [ ] Realizo consulta de disponibilidade






